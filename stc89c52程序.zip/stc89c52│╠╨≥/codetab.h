#ifndef __CODETAB_H__
#define __CODETAB_H__

extern const unsigned char code wenzi[8][32];
extern const unsigned char code F8X16[];
extern const unsigned char code bilibili[];
#endif

